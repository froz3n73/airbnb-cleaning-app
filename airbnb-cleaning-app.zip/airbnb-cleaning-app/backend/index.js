require("dotenv").config();

const express = require("express");
const cors = require("cors");
const { Pool } = require("pg");
const bcrypt = require("bcrypt");

const app = express();

app.use(cors());
app.use(express.json());

const pool = new Pool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
});

pool
  .connect()
  .then(() => console.log("✅ Conectado a PostgreSQL"))
  .catch((err) => console.error("❌ Error conexión DB:", err));

app.get("/", (req, res) => {
  res.send("Servidor funcionando 🚀");
});

app.get("/properties/:userId", async (req, res) => {
  const { userId } = req.params;

  try {
    const result = await pool.query(
      `
      SELECT p.*
      FROM properties p
      INNER JOIN assignments a ON a.property_id = p.id
      INNER JOIN users u ON u.id = a.user_id
      WHERE u.id = $1
        AND u.status = 'active'
        AND p.is_active = true
        AND a.is_active = true
      ORDER BY p.property_name ASC
      `,
      [userId]
    );

    res.json(result.rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error obteniendo propiedades" });
  }
});

app.post("/login", async (req, res) => {
  const { email, password } = req.body;

  try {
    const result = await pool.query(
      `
      SELECT id, name, email, role, status, password_hash
      FROM users
      WHERE email = $1
      LIMIT 1
      `,
      [email]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Usuario no encontrado" });
    }

    const user = result.rows[0];

    if (user.status !== "active") {
      return res.status(403).json({ error: "Usuario inactivo" });
    }

    const isValidPassword = await bcrypt.compare(password, user.password_hash);

    if (!isValidPassword) {
      return res.status(401).json({ error: "Contraseña incorrecta" });
    }

    res.json({
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      status: user.status,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error en login" });
  }
});

app.post("/admin/create-user", async (req, res) => {
  const { name, email, password } = req.body;

  try {
    const password_hash = await bcrypt.hash(password, 10);

    const result = await pool.query(
      `
      INSERT INTO users (name, email, password_hash, role, status)
      VALUES ($1, $2, $3, 'worker', 'active')
      RETURNING id, name, email, role, status
      `,
      [name, email, password_hash]
    );

    res.json(result.rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error creando usuario" });
  }
});

app.get("/admin/workers", async (req, res) => {
  try {
    const result = await pool.query(
      `
      SELECT id, name, email, role, status
      FROM users
      WHERE role = 'worker' AND status = 'active'
      ORDER BY name ASC
      `
    );

    res.json(result.rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error obteniendo trabajadoras" });
  }
});

app.get("/admin/properties", async (req, res) => {
  try {
    const result = await pool.query(
      `
      SELECT id, property_name, address_line_1, city, door_code, entry_instructions, notes, is_active
      FROM properties
      WHERE is_active = true
      ORDER BY property_name ASC
      `
    );

    res.json(result.rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error obteniendo propiedades" });
  }
});

app.post("/admin/assign-property", async (req, res) => {
  const { userId, propertyId } = req.body;

  try {
    const result = await pool.query(
      `
      INSERT INTO assignments (user_id, property_id, is_active)
      VALUES ($1, $2, true)
      RETURNING id, user_id, property_id
      `,
      [userId, propertyId]
    );

    res.json(result.rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error asignando propiedad" });
  }
});

app.post("/admin/create-property", async (req, res) => {
  const {
    property_name,
    address_line_1,
    city,
    door_code,
    entry_instructions,
    notes,
  } = req.body;

  try {
    const result = await pool.query(
      `
      INSERT INTO properties (
        property_name,
        address_line_1,
        city,
        door_code,
        entry_instructions,
        notes,
        is_active
      )
      VALUES ($1, $2, $3, $4, $5, $6, true)
      RETURNING id, property_name, address_line_1, city, door_code, entry_instructions, notes
      `,
      [
        property_name,
        address_line_1,
        city,
        door_code,
        entry_instructions,
        notes,
      ]
    );

    res.json(result.rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error creando propiedad" });
  }
});

app.post("/admin/deactivate-user", async (req, res) => {
  const { userId } = req.body;

  try {
    const result = await pool.query(
      `
      UPDATE users
      SET status = 'inactive'
      WHERE id = $1
      RETURNING id, name, email, role, status
      `,
      [userId]
    );

    res.json(result.rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error desactivando trabajadora" });
  }
});

app.post("/admin/update-property", async (req, res) => {
  const {
    id,
    property_name,
    address_line_1,
    city,
    door_code,
    entry_instructions,
    notes,
  } = req.body;

  try {
    const result = await pool.query(
      `
      UPDATE properties
      SET
        property_name = $1,
        address_line_1 = $2,
        city = $3,
        door_code = $4,
        entry_instructions = $5,
        notes = $6
      WHERE id = $7
      RETURNING id, property_name, address_line_1, city, door_code, entry_instructions, notes
      `,
      [
        property_name,
        address_line_1,
        city,
        door_code,
        entry_instructions,
        notes,
        id,
      ]
    );

    res.json(result.rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error actualizando propiedad" });
  }
});

const PORT = process.env.PORT || 4000;

app.listen(PORT, () => {
  console.log(`🚀 Backend corriendo en http://localhost:${PORT}`);
});