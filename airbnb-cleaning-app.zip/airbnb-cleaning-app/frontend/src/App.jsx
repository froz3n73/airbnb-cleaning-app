import { useState, useEffect } from "react";
import axios from "axios";
import WorkerView from "./WorkerView";

function App() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [user, setUser] = useState(null);
  const [properties, setProperties] = useState([]);

  const [newName, setNewName] = useState("");
  const [newEmail, setNewEmail] = useState("");
  const [newPassword, setNewPassword] = useState("");

  const [workers, setWorkers] = useState([]);
  const [adminProperties, setAdminProperties] = useState([]);
  const [selectedWorker, setSelectedWorker] = useState("");
  const [selectedProperty, setSelectedProperty] = useState("");

  const [propertyName, setPropertyName] = useState("");
  const [propertyAddress, setPropertyAddress] = useState("");
  const [propertyCity, setPropertyCity] = useState("");
  const [propertyCode, setPropertyCode] = useState("");
  const [propertyInstructions, setPropertyInstructions] = useState("");
  const [propertyNotes, setPropertyNotes] = useState("");
   const handleLogout = () => {
    setUser(null);
    setEmail("");
    setPassword("");
    setProperties([]);
  };

  const handleLogin = async (e) => {
    e.preventDefault();

    try {
      const res = await axios.post(`${import.meta.env.VITE_API_URL}/login`, {
        email,
        password,
      });

      setUser(res.data);
    } catch (err) {
      alert("Error login");
    }
  };

  const loadAdminData = async () => {
    try {
      const workersRes = await axios.get(`${import.meta.env.VITE_API_URL}/admin/workers`);
setWorkers(workersRes.data || []);

const propertiesRes = await axios.get(`${import.meta.env.VITE_API_URL}/admin/properties`);
setAdminProperties(propertiesRes.data || []);
    } catch (err) {
      console.error(err);
    }
  };

  const handleCreateUser = async (e) => {
    e.preventDefault();

    try {
      await axios.post(`${import.meta.env.VITE_API_URL}/login`, {
        name: newName,
        email: newEmail,
        password: newPassword,
      });

      alert("Trabajadora creada");
      setNewName("");
      setNewEmail("");
      setNewPassword("");
      loadAdminData();
    } catch (err) {
      alert("Error creando trabajadora");
    }
  };

  const handleAssignProperty = async (e) => {
    e.preventDefault();

    try {
      await axios.post(`${import.meta.env.VITE_API_URL}/admin/assign-property`, {
        userId: selectedWorker,
        propertyId: selectedProperty,
      });

      alert("Propiedad asignada");
      setSelectedWorker("");
      setSelectedProperty("");
    } catch (err) {
      alert("Error asignando propiedad");
    }
  };

  const handleCreateProperty = async (e) => {
    e.preventDefault();

    try {
      await axios.post(`${import.meta.env.VITE_API_URL}/admin/assign-property`, {
        property_name: propertyName,
        address_line_1: propertyAddress,
        city: propertyCity,
        door_code: propertyCode,
        entry_instructions: propertyInstructions,
        notes: propertyNotes,
      });

      alert("Propiedad creada");
      setPropertyName("");
      setPropertyAddress("");
      setPropertyCity("");
      setPropertyCode("");
      setPropertyInstructions("");
      setPropertyNotes("");
      loadAdminData();
    } catch (err) {
      alert("Error creando propiedad");
    }
  };

  const handleDeactivateWorker = async (workerId) => {
    try {
      await axios.post(`${import.meta.env.VITE_API_URL}/admin/deactivate-user`, {
        userId: workerId,
      });

      alert("Trabajadora desactivada");
      loadAdminData();
    } catch (err) {
      alert("Error desactivando trabajadora");
    }
  };

  useEffect(() => {
    if (!user) return;

    if (user.role === "admin") {
      loadAdminData();
      return;
    }

    axios
      .get(`${import.meta.env.VITE_API_URL}/properties/${user.id}`)
      .then((res) => {
        setProperties(res.data || []);
      })
      .catch(() => {});
  }, [user]);

  if (!user) {
    return (
      <div style={{ padding: 40 }}>
        <h1>Login</h1>

        <form onSubmit={handleLogin}>
          <input
            placeholder="correo"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />

          <br />
          <br />

          <input
            placeholder="password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />

          <br />
          <br />

          <button>Entrar</button>
        </form>
      </div>
    );
  }

  if (user.role === "admin") {
    return (
      <div style={{ padding: 40 }}>
        <h1>Panel Admin</h1>
        <p>Bienvenido, {user.name}</p>

        <h2>Crear trabajadora</h2>

        <form onSubmit={handleCreateUser}>
          <input
            placeholder="Nombre"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
          />

          <br />
          <br />

          <input
            placeholder="Correo"
            value={newEmail}
            onChange={(e) => setNewEmail(e.target.value)}
          />

          <br />
          <br />

          <input
            placeholder="Contraseña"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
          />

          <br />
          <br />

          <button>Crear trabajadora</button>
        </form>

        <hr style={{ margin: "30px 0" }} />

        <h2>Crear propiedad</h2>

        <form onSubmit={handleCreateProperty}>
          <input
            placeholder="Nombre de propiedad"
            value={propertyName}
            onChange={(e) => setPropertyName(e.target.value)}
          />

          <br />
          <br />

          <input
            placeholder="Dirección"
            value={propertyAddress}
            onChange={(e) => setPropertyAddress(e.target.value)}
          />

          <br />
          <br />

          <input
            placeholder="Ciudad"
            value={propertyCity}
            onChange={(e) => setPropertyCity(e.target.value)}
          />

          <br />
          <br />

          <input
            placeholder="Código"
            value={propertyCode}
            onChange={(e) => setPropertyCode(e.target.value)}
          />

          <br />
          <br />

          <input
            placeholder="Instrucciones"
            value={propertyInstructions}
            onChange={(e) => setPropertyInstructions(e.target.value)}
          />

          <br />
          <br />

          <input
            placeholder="Notas"
            value={propertyNotes}
            onChange={(e) => setPropertyNotes(e.target.value)}
          />

          <br />
          <br />

          <button>Crear propiedad</button>
        </form>

        <hr style={{ margin: "30px 0" }} />

        <h2>Asignar propiedad</h2>

        <form onSubmit={handleAssignProperty}>
          <select
            value={selectedWorker}
            onChange={(e) => setSelectedWorker(e.target.value)}
          >
            <option value="">Selecciona trabajadora</option>
            {Array.isArray(workers) &&
              workers.map((worker) => (
                <option key={worker.id} value={worker.id}>
                  {worker.name} - {worker.email}
                </option>
              ))}
          </select>

          <br />
          <br />

          <select
            value={selectedProperty}
            onChange={(e) => setSelectedProperty(e.target.value)}
          >
            <option value="">Selecciona propiedad</option>
            {Array.isArray(adminProperties) &&
              adminProperties.map((property) => (
                <option key={property.id} value={property.id}>
                  {property.property_name} - {property.address_line_1}
                </option>
              ))}
          </select>

          <br />
          <br />

          <button>Asignar propiedad</button>
        </form>

        <hr style={{ margin: "30px 0" }} />

        <h2>Trabajadoras activas</h2>

        {Array.isArray(workers) && workers.length > 0 ? (
          workers.map((worker) => (
            <div
              key={worker.id}
              style={{
                marginBottom: 15,
                padding: 12,
                border: "1px solid #ccc",
                borderRadius: 8,
              }}
            >
              <strong>{worker.name}</strong>
              <br />
              {worker.email}
              <br />
              Estado: {worker.status}
              <br />
              <br />
              <button onClick={() => handleDeactivateWorker(worker.id)}>
                Desactivar
              </button>
            </div>
          ))
        ) : (
          <p>No hay trabajadoras activas.</p>
        )}

        <hr style={{ margin: "30px 0" }} />

        <h2>Propiedades activas</h2>

        {Array.isArray(adminProperties) && adminProperties.length > 0 ? (
          adminProperties.map((property) => (
            <div
              key={property.id}
              style={{
                marginBottom: 15,
                padding: 12,
                border: "1px solid #ccc",
                borderRadius: 8,
              }}
            >
              <strong>{property.property_name}</strong>
              <br />
              {property.address_line_1}
              <br />
              {property.city}
            </div>
          ))
        ) : (
          <p>No hay propiedades activas.</p>
        )}
      </div>
    );
  }

  return <WorkerView user={user} onLogout={handleLogout} />;
}
  

export default App;